package cells;

public class MoneyCellAdapter {

    
}
